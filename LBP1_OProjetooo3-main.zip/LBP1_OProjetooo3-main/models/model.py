class User:
    users_db = {
        'estudante': {'username': 'estudante', 'password': 'senha123'},
        'admin': {'username': 'admin', 'password': 'admin123'}
    }
    @classmethod
    def get_user(cls, username):
        user_data = cls.users_db.get(username) 
        if user_data:
            return User(user_data['username'], user_data['password']) 
        return None

    def __init__(self, username, password):
        self.username = username
        self.password = password

