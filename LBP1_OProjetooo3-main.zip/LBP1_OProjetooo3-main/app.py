from flask import Flask
from controlers import controller as controller_app  

app = controller_app

if __name__ == '__main__':
    app.run(debug=True)  

