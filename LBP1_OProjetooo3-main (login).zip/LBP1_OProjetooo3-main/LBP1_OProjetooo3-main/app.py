from flask import Flask, session, redirect, url_for, request
from controlers.controller import login, logout, protected_route

app = Flask(__name__)

app.config['SECRET_KEY'] = 'sua_chave_secreta_aqui'

@app.before_request
def require_login():
    allowed_routes = ['login', 'logout']
    if request.endpoint not in allowed_routes and 'username' not in session:
        return redirect(url_for('login'))
    
app.add_url_rule('/', view_func=login, methods=['GET', 'POST'])

app.add_url_rule('/dashboard', view_func=protected_route)

app.add_url_rule('/logout', view_func=logout)

if __name__ == '__main__':
    app.run(debug=True)

