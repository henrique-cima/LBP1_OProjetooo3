from flask import Flask, render_template, request, redirect, url_for, flash
from models import User

app = Flask(__name__)
app.secret_key = 'chave_secreta_para_flash'  

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.get_user(username)

        if user and user.password == password:
            flash('Login realizado com sucesso!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Usuário ou senha incorretos.', 'danger')
            return redirect(url_for('login'))

    return render_template('index.html')  

@app.route('/dashboard')
def dashboard():
    return 'Bem-vindo ao Dashboard!'

@app.route('/logout')
def logout():
    flash('Você saiu com sucesso.', 'info')
    return redirect(url_for('login'))
